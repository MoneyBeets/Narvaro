/**
 * Narvaro: 0.1.0
 * Build Date: 2015-05-21
 * Commit Head: a948854
 * JDK: 1.8.0_40
 * ANT: 1.9.4
 *
 */

package edu.csus.ecs.moneybeets.narvaro.database;

import java.util.zip.DataFormatException;

/**
 * Narvaro supported database types.
 *
 */
public enum DatabaseType {

    sqlserver("SQL Server"),
    
    mysql("MySQL"),
    
    ;
    
    private DatabaseType(final String name) {
    	this.name = name;
    }
    
    final String name;
    
    /**
     * @return The database name.
     */
    public String getName() {
    	return name;
    }
    
    /**
     * Converts a string to the proper matching DatabaseType.
     * 
     * @param in The string.
     * @return The database type if found.
     * @throws DataFormatException If input is null or empty, or not found.
     */
    public static DatabaseType fromString(final String in) throws DataFormatException {
    	if ("".equals(in) || in == null) {
    		throw new DataFormatException("Input not found");
    	}
    	for (DatabaseType dbType : DatabaseType.values()) {
    		if (in.equalsIgnoreCase(dbType.toString()) 
    				|| in.equalsIgnoreCase(dbType.getName())) {
    			return dbType;
    		}
    	}
    	throw new DataFormatException("Input not found");
    }
    
}
